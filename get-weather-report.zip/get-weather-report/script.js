document.getElementById("location-form").addEventListener("submit", getWeather);
const apiKey = "86d2dc6043c278fc2a8642ce4ad0b6aa";

function getWeather(e) {
  //e.preventDefault();
  // clearing all existing data
  clearWeatherData();
  const textBox = document.getElementById("location-input");
  const textBoxValue = textBox.value;
  textBox.addEventListener("focus", clearWeatherData);
  // Add an event listener to clear custom validity on input
  textBox.addEventListener("input", function () {
    textBox.setCustomValidity("");
    document.getElementById("location-form").reportValidity();
  });
  // showing warning if input box value in null
  if (textBoxValue.trim().length === 0) {
    textBox.setCustomValidity("Please fill out this field");
    document.getElementById("location-form").reportValidity();
    return;
  }
  // getting weather data
  getWeatherData(textBoxValue).then((data) => {
    if (data.cod === 200) {
      document.getElementById("city-name").innerText = data.name;
      document.getElementById("weather-type").innerText = data.weather[0]?.main;
      document.getElementById("weather-desc").innerText =
        data.weather[0]?.description;
    } else {
      document.getElementById("weather-data").innerText =
        "Error: City not found";
    }
    textBox.value = "";
  });
}

/**
 *
 * @param {*} city for which we want to get the weather forecast
 * @returns weather data of the requested city
 */

async function getWeatherData(city) {
  let response = await fetch(
    `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}`
  );
  let data = await response.json();
  return data;
}

/**
 * clearing all the fields before making any calls
 */
function clearWeatherData() {
  // Clear content of HTML elements
  document.getElementById("city-name").innerText = "";
  document.getElementById("weather-type").innerText = "";
  document.getElementById("weather-desc").innerText = "";
}
